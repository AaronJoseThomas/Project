import sqlite3
from flask import Flask, render_template, request, redirect, url_for, abort

app = Flask(__name__)
DATABASE= 'todos.db'

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def find_todos(todo_id):
    conn = get_db()
    todos = conn.execute("SELECT * FROM todos").fetchall()
    conn.close()
    return render_template('index.html', todos=todos)
@app.route('/')
def get_todos():
    conn = True
    try:
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM todos ORDER BY id DESC")
        todos = cursor.fetchall()
    except sqlite3.Error as e:
        app.logger.error(f"Database error in get_todos: {e}")
        abort(500)
    finally:
        if conn:
            conn.close()
    return render_template('todos.html', todos=todos)

@app.route('/add', methods=['POST'])
def add_todo():
    task = request.form['task']
    conn = get_db()

    conn.execute("INSERT INTO todos (task) VALUES (?)", (task,))
    conn.commit()
    conn.close()
    return redirect(url_for('index'))

@app.route('/delete/<int:id>', methods=['POST'])
def delete_todo(id):
    conn = get_db()
    conn.execute("DELETE FROM todos WHERE id=?", (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('index')) 

if __name__ == '__main__':
    app.run(debug=True)  